﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace QuizSystem.Wpf.Infrastructure
{
    /// <summary>
    /// Bazowa klasa MVVM: obsługuje INotifyPropertyChanged.
    /// Dzięki temu UI samo się odświeża, gdy zmieniasz właściwości w ViewModelu.
    /// </summary>
    public abstract class ObservableObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}
